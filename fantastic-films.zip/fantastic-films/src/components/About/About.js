const About = () => {
    return ( 
        <div> 
            <div className=" w3-animate-opacity w3-text-black">
                <div className="w3-display-middle">
                    <h1 className="w3-midium w3-animate-top"><u>Developer Information</u></h1>
                    <div className="w3-margin-left">
                        <h1 className="w3-small w3-animate-top">Name: Wanga</h1>
                        <h1 className="w3-small w3-animate-top">Surname: Tsewana</h1>
                        <h1 className="w3-small w3-animate-top">Email: wtsewana@gmail.com</h1>
                        <h1 className="w3-small w3-animate-top">Phone: 079 320 3143</h1>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default About;