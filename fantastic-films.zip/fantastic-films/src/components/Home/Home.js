const Home = () => {
    return ( 
        <div>
            <div className=" w3-animate-opacity w3-text-black w3-center">
            <div className="w3-display-middle">
            <h1 className="w3-midium w3-animate-top">Welcome To Fantastic Films</h1>
            <a href="/films" className="w3-btn w3-green w3-animate-bottom">Browse films</a>
            </div>
            </div>
        </div> 
     );
}
export default Home;