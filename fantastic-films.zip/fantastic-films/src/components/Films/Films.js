import classes from './Films.module.css'
 
const Films = ({title,vote_average}) => {
    var xhttp=new XMLHttpRequest();
    xhttp.onreadystatechange=function(){
        if(xhttp.readyState === 4){
            if(xhttp.status === 200){
                let films=JSON.parse(xhttp.responseText);
                let html="";
                let rating_color="w3-grey";
                let rating=0;
                console.log(films);
                for(let i=0;i<films.results.length;i++){
                    rating=films.results[i].vote_average * 10;
                    if(rating===0){
                        rating_color="w3-grey";
                    }else if(rating<50){
                        rating_color="w3-red";
                    }else if(rating<70){
                        rating_color="w3-yellow";
                    }else{
                        rating_color="w3-green";
                    }
                    html+=`<div class="w3-col l3 s12 w3-animate-zoom"><div class="w3-container"><div class="w3-display-container"><img src="https://www.themoviedb.org/t/p/w220_and_h330_face/${films.results[i].backdrop_path}" style="max-height: 500px; width: 100%;"><span class="w3-tag ${rating_color} w3-display-topright">${films.results[i].vote_average}</span><div class="w3-display-middle w3-display-hover"><button class="w3-button w3-black btn-watch-now" data-id="${films.results[i].id}">Watch Now<i class="fa fa-shopping-cart"></i></button></div></div><p class="w3-small Films_movie-name__6mrdr">${films.results[i].title}</p></div></div>`;
                }
                document.getElementById("films").innerHTML="<div class='w3-content'><div class='w3-row'>"+html+"</div></div>";
                var btnWatchNow=document.getElementsByClassName("btn-watch-now");
                for(let i=0;i<btnWatchNow.length;i++){
                    btnWatchNow[i].addEventListener("click",function(){
                        var xhttp=new XMLHttpRequest();
                        xhttp.onreadystatechange=function(){
                            if(this.readyState===4){
                                if(this.status===200){
                                    let json=(JSON.parse(this.responseText));
                                    console.log(json);
                                    let rating=json.vote_average * 10;
                                    let rating_color="w3-grey";
                                    if(rating===0){
                                        rating_color="w3-grey";
                                    }else if(rating<50){
                                        rating_color="w3-red";
                                    }else if(rating<70){
                                        rating_color="w3-yellow";
                                    }else{
                                        rating_color="w3-green";
                                    }
                                    var date=new Date(json.release_date);
                                    
                                    document.getElementById("movie-title").innerText=json.original_title;
                                    document.getElementById("movie-title").insertAdjacentHTML("beforeend",`<span class="w3-small">(${date.getFullYear()})</span>`);
                                    document.getElementById("movie-form-title").value=json.original_title;
                                    document.getElementById("movie-slogan").innerText=json.tagline;
                                    document.getElementById("movie-desc").innerText=json.overview;
                                    document.getElementById("movie-rating").innerText="Rating "+rating.toFixed(1);
                                    document.getElementById("movie-rating").className=`${rating_color} w3-tag`;
                                    document.getElementById("movie-img").src=`https://www.themoviedb.org/t/p/w220_and_h330_face/${json.poster_path}`;
                                    document.getElementById("films").classList.add("w3-hide");
                                    document.getElementById("film-details").classList.remove("w3-hide");
                                    document.getElementById("tag-genre").innerHTML="";
                                    json.genres.forEach(genre => {
                                        document.getElementById("tag-genre").insertAdjacentHTML("afterend",`<span class="w3-tag w3-margin-right w3-grey">${genre.name}</span>`);
                                    });
                                    var http=new XMLHttpRequest();
                                    http.onreadystatechange=function(){
                                        if(this.readyState===4){
                                            if(this.status===200){
                                                console.log(JSON.parse(this.responseText));
                                            }else{

                                            }
                                        }
                                    };
                                    http.open("GET","https://api.trello.com/1/boards/5a4b3c4cbe0188ca9c0b2058/cards?key=6eb508bda626ff893db446eff50d0066&token=ae4a73cb0e40c46f6e642f5f7429394534b35e3b5a4c7c21438e5389eec20497")
                                    http.send();
                                }
                            }
                        };
                        xhttp.open("get",`https://api.themoviedb.org/3/movie/${this.dataset.id}?api_key=d4f7b87d7cedfdfbbb297f46aa3e8779&language=en-US`,true);
                        xhttp.send();
                    });
                }
            }
        }
        
    };
    xhttp.open("GET","https://api.themoviedb.org/3/movie/popular?api_key=d4f7b87d7cedfdfbbb297f46aa3e8779&language=en-US&page=1",true);
    xhttp.send();
    return ( 
        <div className={classes.Films}>
            <div id="films" className=""></div>
                <div id="film-details" className="w3-hide">
                    <div className="w3-third">
                        <img id="movie-img" alt='Movie'/>
                    </div>

                    <div className="w3-twothird">
                        <p id="movie-title"></p>
                        <p id="movie-slogan"></p>
                        <p id="movie-rating" className="w3-yellow w3-tag"></p>
                        <h4>Overiew</h4>
                        <p id="movie-desc" className="w3-medium"></p>
                        <h4>Genres</h4>
                        <p id="tag-genre" className="w3-small"></p>
                        <form id="form-inputs" className="w3-container w3-margin-bottom w3-margin-top">
                            <input type="hidden" id="movie-form-title" name="MovieTitle" />
                            <div className="w3-margin-bottom">
                                <input className="w3-input w3-small w3-border w3-round-large" name='Name' placeholder='First Name' type="text"/>
                            </div>
                            <div className="w3-margin-bottom">     
                                <input className="w3-input w3-small w3-border w3-round-large" name='Surname' placeholder='Last Name' type="text"/>
                            </div>
                            <div className="w3-margin-bottom">     
                                <input className="w3-input w3-small w3-border w3-round-large" name='Email' placeholder='Email' type="text"/>
                            </div>
                            <div className="w3-margin-bottom">     
                                <input className="w3-input w3-small w3-border w3-round-large" name="Number" placeholder='Phone Number' type="text"/>
                            </div>
                            <button id="btn-get-film" type="button" onClick={function(){
                                var element=document.getElementById("btn-get-film");
                                var formData=new FormData(document.getElementById("form-inputs"));
                                var sendData=new FormData();
                                sendData.append("5ffc223c1b802319cb6192fb",formData.get("Name"));
                                sendData.append("5ffc224be427094809dd7b7c",formData.get("Surname"));
                                sendData.append("5ffc22574a33172aa21ccda1",formData.get("Email"));
                                sendData.append("5ffc22612d199f8b0e325ef4",formData.get("Number"));
                                sendData.append("5ffc672ef7f3ca718a1a9b93",formData.get("MovieTitle"));
                                sendData.append("name",`${formData.get("Name")} ${formData.get("Surname")}`);
                                sendData.append("desc",` First name: ${formData.get("Name")}\n Last name: ${formData.get("Surname")} \n Email: ${formData.get("Email")} \n Phone number: ${formData.get("Number")} \n Movie: ${formData.get("MovieTitle")}`);
                                var xhttp=new XMLHttpRequest();
                                element.disabled=true;
                                xhttp.onreadystatechange=function(){
                                    if(xhttp.readyState===4){
                                        element.disabled=false;
                                        console.log(xhttp);
                                        if(xhttp.status===200){
                                            document.getElementById("success-modal").classList.add("w3-show");
                                        }else{
                                            document.getElementById("error-modal").classList.add("w3-show");
                                        }
                                    }
                                };
                                xhttp.open("POST","https://api.trello.com/1/cards?idList=5a4b3c4cbe0188ca9c0b2059&key=6eb508bda626ff893db446eff50d0066&token=ae4a73cb0e40c46f6e642f5f7429394534b35e3b5a4c7c21438e5389eec20497",true);
                                xhttp.send(sendData);
                            }} className="w3-btn w3-green w3-col s12 w3-margin-top">Get film</button>
                        </form>
                    </div>
                </div>
                <div id="success-modal" className="w3-modal">
                    <div className="w3-modal-content w3-animate-top w3-card-4">
                    <header className="w3-container w3-green w3-text-white"> 
                        <span onClick={function(){
                            document.getElementById("success-modal").classList.remove("w3-show");
                        }} 
                        className="w3-button w3-display-topright">&times;</span>
                        <h2>Movie successfully added to Trello</h2>
                    </header>
                    <div className="w3-container">
                        <p>Your movie has been added successfully</p>
                    </div>
                    <footer className="w3-container w3-green w3-text-white">
                        <p>Thank you</p>
                    </footer>
                    </div>
                </div>
                <div id="error-modal" className="w3-modal">
                    <div className="w3-modal-content w3-animate-top w3-card-4">
                    <header className="w3-container w3-red w3-text-white"> 
                        <span onClick={function(){
                            document.getElementById("error-modal").classList.remove("w3-show");
                        }} 
                        className="w3-button w3-display-topright">&times;</span>
                        <h2>Movie failed to added Trello</h2>
                    </header>
                    <div className="w3-container">
                        <p>Your movie has failed to add.</p>
                    </div>
                    <footer className="w3-container w3-red w3-text-white">
                        <p>Thank you</p>
                    </footer>
                    </div>
                </div>
        </div>
     );
}
 
export default Films;