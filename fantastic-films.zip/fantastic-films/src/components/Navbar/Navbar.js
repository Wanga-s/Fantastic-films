const Navbar = (props) => {
    return ( 
        <div>
            <div className="w3-bar w3-amber w3-animate-top">
                <div className="w3-col m4 s3">
                    <a href="/" className="w3-bar-item w3-button w3-grey">Fantastic Films</a>
                </div>
                <div className="w3-col m4 w3-hide-small">
                    <a href="/" className="w3-bar-item w3-col m4 w3-button w3-hide-medium w3-hide-small">Home</a>
                    <a href="/films" className="w3-bar-item w3-col m4 w3-button w3-hide-medium w3-hide-small">Popular Films</a>
                    <a href="/about" className="w3-bar-item w3-col m4 w3-button w3-hide-medium w3-hide-small">About the developer</a>
                </div>
                <div className="w3-col m4 s9">
                <a href="#/" className="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onClick={() => {
                    let element=document.getElementById("mySidebar");
                    if(element.className.includes("w3-hide")){
                        document.getElementById("mySidebar").classList.remove("w3-hide");
                    }else{
                        document.getElementById("mySidebar").classList.add("w3-hide");
                    }
                    
                }}>&#9776;</a>
                </div>
            </div>
            <div className="w3-sidebar w3-bar-block w3-dark-grey w3-animate-left  w3-hide" onClick={() => {
                    document.getElementById("mySidebar").classList.add("w3-hide");
                }} id="mySidebar">
                <button className="w3-bar-item w3-button w3-large">Close &times;</button>
                <a href="/" className="w3-bar-item w3-button">Home</a>
                    <a href="/films" className="w3-bar-item w3-button">Popular Films</a>
                    <a href="/about" className="w3-bar-item w3-button">About the developer</a>
            </div>
        </div>  
    );
}
 
export default Navbar;