import './App.css';
import React from "react";
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Navbar from "./components/Navbar/Navbar";
import Home from "./components/Home/Home";
import Films from "./components/Films/Films";
import About from "./components/About/About";

 function App () {
    return (
      <div>
        <Navbar/>
        <div className="w3-content w3-container">
        <BrowserRouter>
        <Switch>
            <Route path="/" exact element={<Home />}>
              <Home />
            </Route>
            <Route path="/films" element={<Films />}>
              <Films />
            </Route>
            <Route path="/about" element={<About />}>
              <About />
            </Route>
          </Switch>
      </BrowserRouter>
        </div>
        
      </div>
  );
}
export default App;

